const func = require('./mypackage');
func();