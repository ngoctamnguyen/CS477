const moment = require('moment');
console.log(moment().format("LLLL")); 