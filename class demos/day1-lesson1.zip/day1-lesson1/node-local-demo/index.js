require('./home');

console.log(firstname);