var firstname = 'John';
console.log('home.js is executed...');