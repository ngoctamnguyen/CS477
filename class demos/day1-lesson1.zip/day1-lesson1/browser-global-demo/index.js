
console.log('inside index.js: ' + firstname);