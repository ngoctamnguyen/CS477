console.log('start');
setTimeout(() => console.log('Hello World'));
console.log('end');