const util = require('util');
const result = util.format('Hi %d %s', 111, 'John');
console.log(result);