const buf = Buffer.from('Hey!');
console.log(buf[0]);
console.log(buf[1]);
console.log(buf[2]);
console.log(buf[3]);
console.log(buf.toString());