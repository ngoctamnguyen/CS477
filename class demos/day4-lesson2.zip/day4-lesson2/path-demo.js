const { dir } = require('console');
const path = require('path');

// const dir1 = path.dirname('global');
// console.log(dir1);

// console.log(__filename);
// console.log(__dirname);
// const dir2 = path.dirname(__filename);
// console.log(dir2);

const loc = path.join('..', '.', 'public', 'resources', 'index.css');
console.log(loc);
