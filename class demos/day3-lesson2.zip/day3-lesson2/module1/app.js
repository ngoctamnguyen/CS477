const play = require('./play'); 
play.violin(); 
play.clarinet();
