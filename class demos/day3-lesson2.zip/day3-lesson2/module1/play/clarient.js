const play = function() { console.log("Clarinet is playing!"); } 
module.exports = play; 
