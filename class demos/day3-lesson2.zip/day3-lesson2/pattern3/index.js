const person = require('./pattern');
console.log(person);
person.name = 'Edward Hello';
person.getName();

require('./p');