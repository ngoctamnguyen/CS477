const person = require('./pattern');
person.getName();