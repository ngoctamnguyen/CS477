//{}
//{getName: fn}
module.exports.getName = function(){
    console.log('John Smith');
}