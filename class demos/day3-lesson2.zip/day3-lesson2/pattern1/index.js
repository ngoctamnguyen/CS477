const getName = require('./mymodule/pattern1');

getName.getName();