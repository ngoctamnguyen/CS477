const obj = require('./pattern');
console.log(obj);