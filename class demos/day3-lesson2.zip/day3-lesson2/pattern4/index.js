const Person = require('./pattern');
console.log(Person);
const p = new Person('John Smith');
console.log(p);
require('./p');