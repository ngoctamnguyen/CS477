const Person = require('./pattern');
const p = new Person('Edward');