let firstname = 'John';

function getName(){
    return firstname;
}

module.exports = {
    getName
}