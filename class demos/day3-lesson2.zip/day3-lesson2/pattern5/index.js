const person = require('./pattern');
console.log(person.getName());