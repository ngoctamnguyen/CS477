let firstname = 'John';
function getName(){
    console.log(firstname);
}
exports = getName;