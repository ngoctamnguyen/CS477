const fname = require('./person');
console.log(fname);

// console.log(firstname);
// console.log(module.exports, exports);
// console.log(__filename);
// console.log(__dirname);
// console.log(require);