let firstname = 'Edward';

console.log('fs');