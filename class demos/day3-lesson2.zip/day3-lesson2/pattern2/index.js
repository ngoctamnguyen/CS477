const {getName} = require('./pattern2');
console.log(getName);
getName();